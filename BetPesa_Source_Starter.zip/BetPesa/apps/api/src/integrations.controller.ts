import { Controller, Get } from '@nestjs/common';
@Controller('integrations')
export class IntegrationsController {
  @Get('status')
  status() {
    return {
      payments: { mode: process.env.PAYMENTS_MODE ?? 'disabled', mtn: 'not-configured', airtel: 'not-configured' },
      sportsData: process.env.SPORTS_DATA_API_KEY ? 'configured-needs-validation' : 'not-configured',
      note: 'No real payments or betting are enabled in this starter.'
    };
  }
}
