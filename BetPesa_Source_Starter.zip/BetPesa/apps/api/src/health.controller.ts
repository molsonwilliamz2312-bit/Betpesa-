import { Controller, Get } from '@nestjs/common';
@Controller('health')
export class HealthController {
  @Get()
  getHealth() { return { status: 'ok', service: 'betpesa-api', environment: process.env.NODE_ENV ?? 'development' }; }
}
