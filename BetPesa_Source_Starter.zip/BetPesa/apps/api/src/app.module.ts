import { Module } from '@nestjs/common';
import { HealthController } from './health.controller';
import { IntegrationsController } from './integrations.controller';
@Module({ controllers: [HealthController, IntegrationsController] })
export class AppModule {}
