/** Adapter contract for a licensed sports-data/odds supplier. */
export interface SportsEvent { providerId: string; sport: string; competition?: string; home: string; away: string; startsAt: string; status: string; }
export interface SportsDataProvider { listUpcomingEvents(sport?: string): Promise<SportsEvent[]>; getEvent(providerId: string): Promise<SportsEvent | null>; }
