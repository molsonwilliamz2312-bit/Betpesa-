/** Provider contract only. Implement against official merchant documentation and test credentials. */
export type PaymentProviderName = 'mtn_momo' | 'airtel_money';
export interface CreatePaymentRequest { amount: number; currency: 'UGX'; customerPhoneE164: string; reference: string; callbackUrl: string; }
export interface PaymentResult { providerReference: string; status: 'pending' | 'confirmed' | 'failed'; }
export interface PaymentProvider {
  readonly name: PaymentProviderName;
  createDeposit(request: CreatePaymentRequest): Promise<PaymentResult>;
  verifyCallback(headers: Record<string, string | string[] | undefined>, rawBody: Buffer): Promise<boolean>;
  queryStatus(providerReference: string): Promise<PaymentResult>;
}
// Never treat a browser redirect or client-supplied status as proof of payment.
