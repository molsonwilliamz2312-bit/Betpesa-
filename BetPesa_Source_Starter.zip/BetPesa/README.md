# BetPesa — source-code starter

This is a runnable development foundation for the BetPesa concept, not a production-ready or licensed gambling service. It includes a Next.js web UI, a NestJS API scaffold, PostgreSQL schema, Docker Compose, and provider integration contracts. It does **not** include live odds, real payment credentials, casino content, production settlement certification, or native App Store/Play Store binaries.

## Prerequisites
- Node.js 20+
- Docker Desktop / Docker Engine
- npm

## Run locally
1. Copy `.env.example` to `.env` and replace development secrets before any shared deployment.
2. Run `docker compose up -d db`.
3. In one terminal: `cd apps/api && npm install && npm run start:dev`.
4. In another terminal: `cd apps/web && npm install && npm run dev`.
5. Open `http://localhost:3000`; API health endpoint is `http://localhost:4000/health`.

The included wallet is not connected to real money. Do not accept deposits or bets from the public using this starter. Payment endpoints are intentionally integration interfaces only.

## Monorepo contents
- `apps/web`: responsive Next.js customer-facing concept UI.
- `apps/api`: NestJS API scaffold with health route and provider interfaces.
- `packages/shared`: shared TypeScript types.
- `database/schema.sql`: initial relational schema and immutable-style ledger structure.
- `docs/PRODUCTION_CHECKLIST.md`: launch blockers and security checklist.

## Production requirements
Before real-money use, complete the applicable Ugandan licensing/approvals, legal review, KYC/age checks, responsible-gambling controls, independent security review, payment provider approval, odds/data contracts, casino/virtual-game provider contracts, reconciliation, incident response, and load testing. Keep all provider secrets server-side. Never trust a browser-reported payment success.
