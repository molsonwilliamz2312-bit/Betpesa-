export type Sport = 'football' | 'basketball' | 'tennis' | 'other';
export type BetStatus = 'pending' | 'accepted' | 'won' | 'lost' | 'void' | 'rejected';
export interface PublicEvent { id: string; sport: Sport; competition: string; home: string; away: string; startsAt: string; status: 'scheduled' | 'live' | 'finished'; }
export interface PublicSelection { id: string; name: string; decimalOdds: number; status: 'open' | 'suspended' | 'closed'; }
export interface ApiHealth { status: 'ok'; service: 'betpesa-api'; environment: string; }
