CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TYPE account_status AS ENUM ('pending','active','suspended','closed');
CREATE TYPE payment_status AS ENUM ('created','pending','confirmed','failed','cancelled','reversed');
CREATE TYPE bet_status AS ENUM ('pending','accepted','won','lost','void','rejected','cashout_pending');
CREATE TABLE users (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), email TEXT UNIQUE, phone_e164 TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, display_name TEXT NOT NULL, date_of_birth DATE,
 status account_status NOT NULL DEFAULT 'pending', created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 CHECK (email IS NULL OR length(email) <= 254)
);
CREATE TABLE wallets (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL UNIQUE REFERENCES users(id),
 currency CHAR(3) NOT NULL DEFAULT 'UGX', created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- Store money as integer minor units; for UGX the application must define a consistent whole-shilling convention.
CREATE TABLE wallet_transactions (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), wallet_id UUID NOT NULL REFERENCES wallets(id),
 idempotency_key TEXT NOT NULL UNIQUE, kind TEXT NOT NULL CHECK (kind IN ('deposit','withdrawal','stake','payout','refund','adjustment')),
 amount BIGINT NOT NULL CHECK (amount > 0), direction TEXT NOT NULL CHECK (direction IN ('credit','debit')),
 status TEXT NOT NULL CHECK (status IN ('pending','posted','failed','reversed')),
 provider TEXT, provider_reference TEXT, related_bet_id UUID, metadata JSONB NOT NULL DEFAULT '{}',
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), posted_at TIMESTAMPTZ
);
CREATE INDEX wallet_tx_wallet_created ON wallet_transactions(wallet_id, created_at DESC);
CREATE TABLE payment_intents (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL REFERENCES users(id),
 provider TEXT NOT NULL CHECK (provider IN ('mtn_momo','airtel_money')),
 direction TEXT NOT NULL CHECK (direction IN ('deposit','withdrawal')), amount BIGINT NOT NULL CHECK (amount > 0),
 currency CHAR(3) NOT NULL DEFAULT 'UGX', status payment_status NOT NULL DEFAULT 'created',
 idempotency_key TEXT NOT NULL UNIQUE, provider_reference TEXT UNIQUE, callback_payload JSONB,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE events (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), provider TEXT NOT NULL, provider_event_id TEXT,
 sport TEXT NOT NULL, competition TEXT, home_name TEXT NOT NULL, away_name TEXT NOT NULL,
 starts_at TIMESTAMPTZ NOT NULL, status TEXT NOT NULL DEFAULT 'scheduled', raw_data JSONB NOT NULL DEFAULT '{}',
 UNIQUE(provider, provider_event_id)
);
CREATE TABLE markets (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), event_id UUID NOT NULL REFERENCES events(id),
 provider_market_id TEXT, market_type TEXT NOT NULL, name TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open',
 UNIQUE(event_id, provider_market_id)
);
CREATE TABLE selections (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), market_id UUID NOT NULL REFERENCES markets(id),
 provider_selection_id TEXT, name TEXT NOT NULL, decimal_odds NUMERIC(10,4) NOT NULL CHECK (decimal_odds > 1),
 status TEXT NOT NULL DEFAULT 'open', updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE bets (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL REFERENCES users(id),
 stake BIGINT NOT NULL CHECK (stake > 0), currency CHAR(3) NOT NULL DEFAULT 'UGX',
 combined_odds NUMERIC(16,6) NOT NULL CHECK (combined_odds > 1), potential_payout BIGINT NOT NULL CHECK (potential_payout > 0),
 status bet_status NOT NULL DEFAULT 'pending', idempotency_key TEXT NOT NULL UNIQUE,
 accepted_at TIMESTAMPTZ, settled_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE bet_legs (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), bet_id UUID NOT NULL REFERENCES bets(id),
 event_id UUID NOT NULL REFERENCES events(id), market_id UUID NOT NULL REFERENCES markets(id),
 selection_id UUID NOT NULL REFERENCES selections(id), odds_at_placement NUMERIC(10,4) NOT NULL CHECK (odds_at_placement > 1),
 outcome TEXT NOT NULL DEFAULT 'pending'
);
ALTER TABLE wallet_transactions ADD CONSTRAINT wallet_tx_bet_fk FOREIGN KEY (related_bet_id) REFERENCES bets(id);
CREATE TABLE audit_logs (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), actor_user_id UUID REFERENCES users(id), action TEXT NOT NULL,
 target_type TEXT NOT NULL, target_id UUID, ip_address INET, details JSONB NOT NULL DEFAULT '{}',
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
