# Production readiness checklist

## Legal and operating approval
- [ ] Confirm the applicable Ugandan gambling licence(s), approvals, and permitted product types with the regulator and qualified counsel.
- [ ] Obtain written approval/contract for every payment method and gambling provider.
- [ ] Define age/identity verification, AML/fraud procedures, privacy notice, retention schedule, complaints, and dispute handling.
- [ ] Implement responsible-gambling limits, self-exclusion, time-outs, and support information.

## Payments
- [ ] Implement official MTN and Airtel merchant API adapters using their current documentation.
- [ ] Verify callback signatures against the raw request body.
- [ ] Require server-to-server status confirmation; do not trust redirects.
- [ ] Use idempotency keys and database transactions; reconcile daily against provider statements.
- [ ] Never store PINs, OTPs, or mobile-money credentials.
- [ ] Obtain provider sandbox and production credentials through official merchant onboarding.

## Betting and game providers
- [ ] Sign an appropriate sports data/odds agreement.
- [ ] Implement odds freshness checks and suspend markets during updates.
- [ ] Define settlement rules and audit/replay process.
- [ ] Sign contracts and complete certification for casino, virtual sports, and live dealer providers.
- [ ] Implement provider callbacks, signature verification, and financial reconciliation.

## Security and reliability
- [ ] Replace development secrets; use managed secret storage.
- [ ] Add full authentication, MFA for admins, RBAC, rate limits, CSRF protection where applicable, and secure headers.
- [ ] Add migrations, transactional wallet ledger logic, concurrency/duplicate-request tests, and backups with restore drills.
- [ ] Add logging, alerting, incident response, DDoS protection, vulnerability scanning, and independent penetration testing.
- [ ] Load-test and test failure recovery before any public launch.
- [ ] Build native app releases, privacy disclosures, and store compliance submissions separately.

## Current scaffold status
- Web preview: included.
- API health endpoint and integration status: included.
- Initial database schema: included; migrations and repository layer still need implementation.
- Production auth, bet placement/settlement, real wallet posting, payment callbacks: not implemented.
- Real odds, casino/virtual/live games, MTN/Airtel credentials: not included.
- Native Android/iOS builds: not included.
